# ALJUER — MVP starter

This is a Flutter starter project for the ALJUER marketplace.

## Included in this first source build
- Premium black/gold visual identity
- Home feed with sample products
- Search and category filters
- Favorites (in-memory)
- Add-listing preview (in-memory)
- Language selector labels for Arabic, German, English, Turkish, French and Spanish

## Not yet connected
This is a UI prototype, not a production marketplace. It does not yet include:
- Real accounts, authentication, database or cloud image storage
- Real-time chat, notifications or moderation tools
- Payment processing, seller payouts, refunds or subscription billing
- Secure owner/admin login and audit logs
- Full translations (the selector is a UI placeholder)
- App Store / Google Play signing and publishing

## Run
1. Install Flutter SDK.
2. Create a project or use this folder as the project root.
3. Run `flutter pub get`
4. Run `flutter run`

## Business rules to implement on the server
- Marketplace commission: 3% of successful eligible transactions.
- Seller subscription: EUR 4.99 per month.
- Buyer account: free.
- Never calculate or collect money only on the client. The backend/payment provider must calculate fees, handle refunds, currency conversion, seller verification, tax and payout rules.

## Owner security
The production owner role must be assigned server-side to a verified owner account. Never rely on a hidden button or a client-side role flag for admin security. Use MFA, secure recovery, least privilege, and an audit log.
