import 'package:flutter/material.dart';

void main() => runApp(const AljuerApp());

const gold = Color(0xFFD6B46A);
const ink = Color(0xFF111827);

class Product {
  Product(this.title, this.category, this.price, this.country, this.icon);
  final String title, category, country;
  final double price;
  final IconData icon;
}

class AljuerApp extends StatefulWidget {
  const AljuerApp({super.key});
  @override
  State<AljuerApp> createState() => _AljuerAppState();
}

class _AljuerAppState extends State<AljuerApp> {
  String language = 'العربية';
  final products = <Product>[
    Product('هاتف Samsung Galaxy', 'هواتف', 250, 'ألمانيا', Icons.smartphone),
    Product('سيارة مستعملة', 'سيارات', 4500, 'ألمانيا', Icons.directions_car),
    Product('أريكة منزلية', 'أثاث', 180, 'فرنسا', Icons.weekend),
    Product('ساعة ذكية', 'إلكترونيات', 75, 'تركيا', Icons.watch),
  ];
  final favorites = <int>{};
  int tab = 0;
  String category = 'الكل';
  String query = '';

  @override
  Widget build(BuildContext context) {
    final shown = products.asMap().entries.where((e) {
      final p = e.value;
      return (category == 'الكل' || p.category == category) &&
          p.title.toLowerCase().contains(query.toLowerCase());
    }).toList();

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ALJUER',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF7F7F5),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(backgroundColor: ink, foregroundColor: Colors.white),
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('ALJUER', style: TextStyle(color: gold, fontWeight: FontWeight.w900, letterSpacing: 2)),
          actions: [
            DropdownButton<String>(
              value: language,
              dropdownColor: ink,
              underline: const SizedBox(),
              style: const TextStyle(color: Colors.white),
              items: ['العربية','Deutsch','English','Türkçe','Français','Español']
                  .map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
              onChanged: (v) => setState(() => language = v ?? language),
            ),
            const SizedBox(width: 12),
          ],
        ),
        body: IndexedStack(
          index: tab,
          children: [
            _home(shown),
            _favorites(),
            const _InfoPage(title: 'الرسائل', message: 'ستُفعّل المحادثات بعد ربط الخادم وقاعدة البيانات.'),
            const _InfoPage(title: 'حسابي', message: 'تسجيل الحساب والتحقق من البريد والهاتف ضمن مرحلة ربط الخلفية.'),
          ],
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (v) => setState(() => tab = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.favorite_border), label: 'المفضلة'),
            NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'الرسائل'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: ink,
          foregroundColor: gold,
          onPressed: _newListing,
          icon: const Icon(Icons.add),
          label: const Text('أضف إعلاناً'),
        ),
      ),
    );
  }

  Widget _home(List<MapEntry<int, Product>> shown) => ListView(
    padding: const EdgeInsets.fromLTRB(16, 18, 16, 90),
    children: [
      const Text('سوق العالم بين يديك', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      const SizedBox(height: 5),
      const Text('اشترِ وبِع بسهولة في مكان واحد.', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 18),
      TextField(
        decoration: InputDecoration(
          hintText: 'ابحث عن منتج...',
          prefixIcon: const Icon(Icons.search),
          filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
        onChanged: (v) => setState(() => query = v),
      ),
      const SizedBox(height: 18),
      const Text('الأقسام', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      Wrap(spacing: 8, runSpacing: 8, children: ['الكل','هواتف','سيارات','أثاث','إلكترونيات']
        .map((c) => ChoiceChip(label: Text(c), selected: category == c,
          selectedColor: gold.withOpacity(.35), onSelected: (_) => setState(() => category = c))).toList()),
      const SizedBox(height: 20),
      const Text('أحدث المنتجات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      ...shown.map((entry) => _productTile(entry.key, entry.value)),
      if (shown.isEmpty) const Padding(
        padding: EdgeInsets.all(24), child: Center(child: Text('لا توجد نتائج مطابقة.'))),
      const SizedBox(height: 16),
      const Card(
        child: Padding(
          padding: EdgeInsets.all(14),
          child: Text('نموذج تجريبي: المنتجات المعروضة بيانات توضيحية وليست إعلانات حقيقية.',
            style: TextStyle(color: Colors.black54)),
        ),
      )
    ],
  );

  Widget _productTile(int index, Product p) => Card(
    margin: const EdgeInsets.only(bottom: 10),
    child: ListTile(
      contentPadding: const EdgeInsets.all(12),
      leading: CircleAvatar(backgroundColor: gold.withOpacity(.22), child: Icon(p.icon, color: ink)),
      title: Text(p.title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('${p.category} • ${p.country}'),
      trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text('${p.price.toStringAsFixed(2)} €', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
        IconButton(
          visualDensity: VisualDensity.compact,
          onPressed: () => setState(() => favorites.contains(index) ? favorites.remove(index) : favorites.add(index)),
          icon: Icon(favorites.contains(index) ? Icons.favorite : Icons.favorite_border,
            color: favorites.contains(index) ? Colors.red : Colors.grey),
        )
      ]),
    ),
  );

  Widget _favorites() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('المفضلة', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      if (favorites.isEmpty) const Text('لم تحفظ أي منتج بعد.'),
      ...favorites.map((i) => _productTile(i, products[i])),
    ],
  );

  void _newListing() {
    final title = TextEditingController();
    final price = TextEditingController();
    showModalBottomSheet(context: context, isScrollControlled: true, builder: (ctx) => Padding(
      padding: EdgeInsets.only(left: 20, right: 20, top: 24, bottom: MediaQuery.of(ctx).viewInsets.bottom + 24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('إضافة إعلان تجريبي', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(controller: title, decoration: const InputDecoration(labelText: 'اسم المنتج')),
        TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعر باليورو')),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: () {
            final value = double.tryParse(price.text.replaceAll(',', '.'));
            if (title.text.trim().isEmpty || value == null || value < 0) return;
            setState(() => products.insert(0, Product(title.text.trim(), 'أخرى', value, 'غير محدد', Icons.inventory_2)));
            Navigator.pop(ctx);
          },
          child: const Text('إضافة إلى المعاينة'),
        ),
        const SizedBox(height: 8),
        const Text('الحفظ محلي داخل هذه الجلسة فقط؛ النشر العام يحتاج قاعدة بيانات.', style: TextStyle(fontSize: 12, color: Colors.black54)),
      ]),
    ));
  }
}

class _InfoPage extends StatelessWidget {
  const _InfoPage({required this.title, required this.message});
  final String title, message;
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(padding: const EdgeInsets.all(24), child: Column(
      mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.construction, size: 48, color: gold),
        const SizedBox(height: 12),
        Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(message, textAlign: TextAlign.center),
      ],
    )),
  );
}
